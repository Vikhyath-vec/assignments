#include "types.h"
#include "stat.h"
#include "user.h"

int n = 3;
int main(int argc, char *argv[])
{
    int i;
    printf(1, "Priorities are:\n");
    for(i = 0; i < n; i++)
    {
        int pid = fork();
        if(pid == 0)
        {
            setpriority((i + 6) % 10);
            sleep(2);           
            printf(1, "%d",(i + 6)%10);
            break;
            // exit();
        }
    }
    for(i = 0; i < n; i++)
    {
        wait();
    }
    exit();
}