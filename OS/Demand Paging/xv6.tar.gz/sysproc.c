#include "types.h"
#include "x86.h"
#include "defs.h"
#include "date.h"
#include "param.h"
#include "memlayout.h"
#include "mmu.h"
#include "proc.h"
#ifndef LAPIC_C
#define LAPIC_C
#endif
#ifndef DATE_H
#define DATE_H
#endif
// #include "lapic.c"

int
sys_fork(void)
{
  return fork();
}

int
sys_exit(void)
{
  exit();
  return 0;  // not reached
}

int
sys_wait(void)
{
  return wait();
}

int
sys_kill(void)
{
  int pid;

  if(argint(0, &pid) < 0)
    return -1;
  return kill(pid);
}

int
sys_getpid(void)
{
  return myproc()->pid;
}

int
sys_sbrk(void)
{
  int addr;
  int n;

  if(argint(0, &n) < 0)
    return -1;
  addr = myproc()->sz;
  if(growproc(n) < 0)
    return -1;
  // myproc()->sz += n;
  return addr;
}

int
sys_sleep(void)
{
  int n;
  uint ticks0;

  if(argint(0, &n) < 0)
    return -1;
  acquire(&tickslock);
  ticks0 = ticks;
  while(ticks - ticks0 < n){
    if(myproc()->killed){
      release(&tickslock);
      return -1;
    }
    sleep(&ticks, &tickslock);
  }
  release(&tickslock);
  return 0;
}

// return how many clock tick interrupts have occurred
// since start.
int
sys_uptime(void)
{
  uint xticks;

  acquire(&tickslock);
  xticks = ticks;
  release(&tickslock);
  return xticks;
}

int
sys_date(void)
{
  struct rtcdate *time;
  if(argptr(0, (void*)&time, sizeof(time)) < 0)
    return -1;
  cmostime(time);
  return 0;
}

int
sys_pgtprint(void)
{
  int i,j,k;
  i = j = k = 0;
  pde_t *page_directory = myproc()->pgdir;
  for(i = 0; i < NPDENTRIES; i++)
  {
    pde_t *page_directory_entry = &page_directory[k];
    if(PTE_P & *page_directory_entry)
    {
      pte_t *page_table = (pte_t*) P2V(PTE_ADDR(*page_directory_entry));
      for(j = 0; j < NPDENTRIES; j++)
      {
        if((PTE_P & page_table[j]) && (PTE_U & page_table[j]))
        {
          
          cprintf("Entry number: %d, pgdir entry num: %d, Pgt entry num: %d, Virtual addr: %p, Physical addr: %p\n", k, i, j, P2V(page_table[j]), page_table[j]);
          k++;
        }
      }
    }
  }
  return 0;
}