#include "types.h"
#include "stat.h"
#include "user.h"

// int arrGlobal[10000];

int 
main(int argc, char *argv[]) 
{
    
    int arrLocal[10000];
    int sum = 0;
    for(int i = 0; i < 10000; i++)
    {
        sum += arrLocal[i];
    }
    pgtprint();
    exit();
}