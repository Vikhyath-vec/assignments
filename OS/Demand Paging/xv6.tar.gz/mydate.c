#include "types.h"
#include "stat.h"
#include "user.h"
#include "date.h"
 
int 
main(int argc, char *argv[]) 
{
    struct rtcdate r;
	if (date(&r)) 
	{
		printf(2, "date failed\n");
		exit();
	}
    if(r.minute+30>59)
	{
		r.hour += 6;
		r.minute = r.minute+30-60;
	}
	else
	{
		r.hour += 5;
		r.minute += 30;
	}
	if(r.hour>=24)
		r.hour -= 24;
	
	char *months[] = {
		"Dummy", 
		"January",
		"February",
		"March",
		"April",
		"May",
		"June",
		"July",
		"August",
		"September",
		"October",
		"November",
		"December"
	};
	char suffix[3] = "th";
	if(r.day == 1 || r.day == 21 || r.day == 31)
	{
		suffix[0] = 's';
		suffix[1] = 't';
	}
	if(r.day == 2 || r.day == 22)
	{
		suffix[0] = 'n';
		suffix[1] = 'd';
	}
	if(r.day == 3 || r.day == 23)
	{
		suffix[0] = 'r';
		suffix[1] = 'd';
	}
	printf(1, "Timestamp is %d:%d:%d %d%s %s, %d\n", r.hour, r.minute, r.second, r.day, suffix, months[r.month], r.year);
    exit();
 }